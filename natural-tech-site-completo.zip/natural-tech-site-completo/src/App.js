import React from "react";

const products = [
  {
    name: "Shampoo Vegano de Camomila",
    description: "Limpeza suave com fragrância natural.",
    price: "29,90",
    image: "https://images.unsplash.com/photo-1600185365483-26dcb1290c60?auto=format&fit=crop&w=600&q=80",
  },
  {
    name: "Sabonete Artesanal de Lavanda",
    description: "Calmante e hidratante para a pele.",
    price: "14,90",
    image: "https://images.unsplash.com/photo-1589187155479-58f2646d24d3?auto=format&fit=crop&w=600&q=80",
  },
  {
    name: "Creme Hidratante Natural",
    description: "Textura leve e nutrição profunda.",
    price: "34,90",
    image: "https://images.unsplash.com/photo-1599058917212-d750089bc63e?auto=format&fit=crop&w=600&q=80",
  },
];

function App() {
  return (
    <div style={{ fontFamily: "Arial", padding: "20px", background: "#f0fdf4" }}>
      <header style={{ textAlign: "center", marginBottom: "30px" }}>
        <h1 style={{ color: "#166534" }}>Natural Tech Cosméticos</h1>
        <p style={{ color: "#15803d" }}>Beleza sustentável ao seu alcance</p>
      </header>

      <main style={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: "20px" }}>
        {products.map((product) => (
          <div
            key={product.name}
            style={{
              background: "#fff",
              borderRadius: "12px",
              padding: "16px",
              width: "250px",
              boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
              textAlign: "center",
            }}
          >
            <img
              src={product.image}
              alt={product.name}
              style={{ width: "100%", height: "160px", objectFit: "cover", borderRadius: "8px" }}
            />
            <h3 style={{ marginTop: "12px", color: "#065f46" }}>{product.name}</h3>
            <p style={{ fontSize: "14px", color: "#444" }}>{product.description}</p>
            <p style={{ fontWeight: "bold", color: "#047857" }}>R$ {product.price}</p>
            <button
              style={{
                marginTop: "10px",
                width: "100%",
                background: "#10b981",
                color: "white",
                border: "none",
                padding: "8px",
                borderRadius: "6px",
                cursor: "pointer",
              }}
            >
              Comprar
            </button>
          </div>
        ))}
      </main>

      <footer style={{ marginTop: "50px", textAlign: "center", color: "#166534" }}>
        <p>© 2025 Natural Tech Cosméticos. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
}

export default App;